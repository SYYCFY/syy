import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
model_path = "C:\\Users\\34890\\.cache\\modelscope\\hub\\Qwen\\Qwen2___5-0___5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)
# 确保模型在适当的设备上
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)
# 定义提示词和对话脚本
def generate_response(prompt):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = model.generate(inputs['input_ids'], max_new_tokens=100)
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response
# 幽默风格的提示
humorous_prompt = "假装你是一位幽默的健康教练，告诉我如何保持健康的生活方式，要有趣一些！"
humorous_response = generate_response(humorous_prompt)

# 严谨风格的提示
serious_prompt = "作为一位严谨的健康学教授，请给我提供一些关于保持健康生活方式的专业建议。"
serious_response = generate_response(serious_prompt)

print("\n幽默的助手回答：", humorous_response)
print("\n严谨的助手回答：", serious_response)
