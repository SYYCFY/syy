import sys

import torch
import transformers
import os
print(f"python version: {os.sys.version}")

#检查GPU使用情况
if torch.cuda.is_available():
    gpu_info = torch.cuda.get_device_properties(0)
    print(f"GPU name: {gpu_info.name}")
    print(f"GPU total memory: {gpu_info.total_memory/(1024**2)} MB")
else:
    print("No GPU available")

#加载Qwen2.5-0.5b模型
from transformers import AutoModelForCausalLM, AutoTokenizer

# 本地模型路径
model_path = "C:\\Users\\34890\\.cache\\modelscope\\hub\\Qwen\\Qwen2___5-0___5B-Instruct"

# 确保在此路径下有 config.json 及其他模型文件
tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True)

# 测试加载成功
print("Model and tokenizer loaded successfully.")

# 输出模型参数量
param_count = sum(p.numel() for p in model.parameters())
print(f"Qwen2.5-0.5B model parameters: {param_count}")

# 3. 输入问题并获取答案
prompt = "帮我写一个去山东潍坊的旅行计划？"
inputs = tokenizer(prompt, return_tensors="pt").to("cuda" if torch.cuda.is_available() else "cpu")

# 生成回答
outputs = model.generate(inputs.input_ids, max_new_tokens=450)
response = tokenizer.decode(outputs[0], skip_special_tokens=True)

print("助手的回答:", response)


