from transformers import AutoModelForCausalLM, AutoTokenizer

# 本地模型路径
model_path = "C:\\Users\\34890\\.cache\\modelscope\\hub\\Qwen\\Qwen2___5-0___5B-Instruct"

# 确保在此路径下有 config.json 及其他模型文件
tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True)

# 测试加载成功
print("Model and tokenizer loaded successfully.")
# 设置填充和结束 token（确保不相同）
tokenizer.pad_token = "<pad>"
tokenizer.eos_token = "<eos>"
prompt = "那一天我二十一岁，在我一生的黄金时代，我有好多奢望。"
inputs = tokenizer(prompt, return_tensors="pt", )
outputs = model.generate(inputs.input_ids,  max_new_tokens=100)
response = tokenizer.decode(outputs[0], skip_special_tokens=True)[len(prompt):]
print(response)