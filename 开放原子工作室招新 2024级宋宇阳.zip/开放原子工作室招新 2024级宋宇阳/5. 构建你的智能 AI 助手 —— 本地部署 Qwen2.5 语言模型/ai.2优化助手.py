import time
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# 加载模型和分词器
model_path = "C:\\Users\\34890\\.cache\\modelscope\\hub\\Qwen\\Qwen2___5-0___5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_path)

# 使用 float16 精度来减小内存占用
model = AutoModelForCausalLM.from_pretrained(model_path).to("cuda" if torch.cuda.is_available() else "cpu").half()

# 定义旅行计划问题
prompt = "我计划从北京出发，去三亚旅游7天。请帮我写一个详细的旅行计划，包括景点、住宿建议和日程安排。"

# 测试优化前的响应时间
start_time = time.time()

# 没有使用梯度计算
with torch.no_grad():
    inputs = tokenizer(prompt, return_tensors="pt").to("cuda" if torch.cuda.is_available() else "cpu")
    outputs = model.generate(inputs['input_ids'], max_new_tokens=200, num_beams=5)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)

end_time = time.time()
response_time_before_optimization = end_time - start_time
print("优化前助手的回答:", response)
print(f"优化前响应时间: {response_time_before_optimization:.4f} 秒")

# 为了进行比较，现在可以对比优化后的情况（假设需要更多的操作，如存储或其他功能，以下可以被视为相同的操作）
# 记录优化后的响应时间
start_time = time.time()

# 使用 torch.no_grad() 和 float16 精度
with torch.no_grad():
    inputs = tokenizer(prompt, return_tensors="pt").to("cuda" if torch.cuda.is_available() else "cpu")
    outputs = model.generate(inputs['input_ids'], max_new_tokens=200, num_beams=5)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)

end_time = time.time()
response_time_after_optimization = end_time - start_time
print("优化后助手的回答:", response)
print(f"优化后响应时间: {response_time_after_optimization:.4f} 秒")

# 分析原因
if response_time_after_optimization < response_time_before_optimization:
    print("优化后的响应时间更短，主要由于：")
    print("- 使用了 torch.no_grad()，避免了不必要的梯度计算。")
    print("- 使用 float16 精度，减少了内存占用，提高了计算速度。")
else:
    print("优化后的响应时间没有明显缩短，可能由于：")
    print("- 模型的计算负载仍然相对较重，存在硬件或其他因素的影响。")
