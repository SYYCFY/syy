import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
# 加载模型和分词器
model_path = "C:\\Users\\34890\\.cache\\modelscope\\hub\\Qwen\\Qwen2___5-0___5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)
# 启动显示
print("我是你的智能助手，随时为你解答问题！")
print("输入 '退出' 退出程序。\n")
def generate_response(prompt):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = model.generate(inputs['input_ids'], max_new_tokens=150)
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response



while True:
    user_input = input("你：")

    if user_input.lower() == "退出":
        print("助手：再见！期待下次为您服务。")
        break

    response = generate_response(user_input)
    print("助手：", response)