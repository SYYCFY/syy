import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
model_path = "C:\\Users\\34890\\.cache\\modelscope\\hub\\Qwen\\Qwen2___5-0___5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)
# 确保模型在适当的设备上
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)
# 定义提示词和对话脚本
def generate_response(prompt):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = model.generate(inputs['input_ids'], max_new_tokens=450)
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response
# 用户询问 1
prompt1 = "作为一个健康生活方式教练，你能告诉我如何保持健康的生活方式？"
response1 = generate_response(prompt1)
# 用户询问 2
prompt2 = "作为一位健康顾问，请给我一些关于保持健康生活方式的具体建议，包括饮食和运动。"
response2 = generate_response(prompt2)
print("用户询问：", prompt1)
print("助手回答：", response1)
print("\n用户询问：", prompt2)
print("助手回答：", response2)

