def run_length_encoding(chars): # 压缩字符串
    # 初始化指针
    i = 0
    j = 0

    # 遍历输入数组
    while i < len(chars):
        # 计算连续字符的长度
        count = 1
        while i + 1 < len(chars) and chars[i] == chars[i + 1]:
            i += 1
            count += 1

        # 将字符和长度追加到结果数组中
        chars[j] = chars[i]
        j += 1

        # 如果长度大于1，追加长度
        if count > 1:
            if count < 10:
                chars[j] = str(count)
            else:
                # 如果长度为10或以上，需要拆分
                for digit in str(count):
                    chars[j] = digit
                    j += 1
        j += 1

        # 移动到下一个字符
        i += 1

    # 返回新数组的长度
    return j


# 示例
chars = list("aabbccc")
new_length = run_length_encoding(chars)
print("".join(chars[:new_length]))  # 输出压缩后的字符串